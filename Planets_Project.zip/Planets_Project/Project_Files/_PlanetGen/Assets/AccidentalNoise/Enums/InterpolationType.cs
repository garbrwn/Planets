namespace AccidentalNoise
{
    public enum InterpolationType
    {
        NONE,
        LINEAR,
        CUBIC,
        QUINTIC
    }
}