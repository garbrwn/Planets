namespace AccidentalNoise
{
    public enum FractalType
    {
        FRACTIONALBROWNIANMOTION,
        RIDGEDMULTI,
        BILLOW,
        MULTI,
        HYBRIDMULTI
    }
}