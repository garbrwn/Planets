namespace AccidentalNoise
{
    public enum BasisType
    {
        VALUE,
        GRADIENT,
        GRADIENTVALUE,
        SIMPLEX,
        WHITE
    }
}