namespace AccidentalNoise
{
    public enum CombinerType
    {
        ADD,
        MULTIPLY,
        MAX,
        MIN,
        AVERAGE
    }
}