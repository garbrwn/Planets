﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;
using AccidentalNoise;
using UnityEngine.UI;


public class MapGenerator : MonoBehaviour {

	[SerializeField]
	int Width = 256;
	[SerializeField]
	int Height = 256;
	[SerializeField]
	int TerrainOctaves = 6;
	[SerializeField]
	double TerrainFrequency = 1.25;

	public GameObject LoadingImage;
	public InputField seedValue;
	public GameObject GeneratePanel;


	int seed = 0;
	Thread generateThread;

	bool generating = false;
	bool planetGenerated = false;
	// Noise Generator module
	ImplicitFractal HeightMap;

	MapData HeightData;

	
	public MapTile[,] Tiles;

	public MeshRenderer HeightMapRenderer;

	void Start () 
	{
		// Set the render object to be invisible until map generation is complete
		HeightMapRenderer.gameObject.SetActive(false);
	}

	//Method to be called by GUI
	public void GeneratePlanetButtonPress(string _seed)
	{
		planetGenerated = false;
		if (seedValue.text != "")
		{
			seed = seedValue.text.GetHashCode ();
		}
		else
		{
			seed = Random.Range (0, int.MaxValue);
			Debug.Log ("Seed not set, applying random seed");
		}
		
		//Start a new thread
		generateThread = new Thread (Generate);
		generateThread.Start ();
		GeneratePanel.SetActive (false);
		LoadingImage.SetActive (true);
		generating = true;
	}

	void Update()
	{

		// Wait until thread has stopped, apply the texture, and display render object
		if (generating)
		{
			if (generateThread.ThreadState == ThreadState.Stopped && !planetGenerated)
			{
				HeightMapRenderer.gameObject.SetActive (true);
				HeightMapRenderer.sharedMaterial.mainTexture = TextureGenerator.GetTexture (Width, Height, Tiles);	
				planetGenerated = true;
				LoadingImage.SetActive (false);
				generating = false;
				GeneratePanel.SetActive (true);
			
			}
		}
	}

	// Init HeightMap data from Accidental Noise Lib
	// This will run on a different thread
	void Generate()
	{		
		Initialize ();

		GetData (HeightMap, ref HeightData);
		LoadTiles ();
	}

	void Initialize()
	{
		HeightMap = new ImplicitFractal (FractalType.MULTI, 
			BasisType.SIMPLEX, 
			InterpolationType.QUINTIC, 
			TerrainOctaves, 
			TerrainFrequency, 
			seed);
	}

	void GetData(ImplicitModuleBase module, ref MapData mapData)
	{
		mapData = new MapData (Width, Height);

		for (int x = 0; x < Width; x++)
		{
			for (int y = 0; y < Height; y++)
			{

				float x1 = 0, x2 = 1;
				float y1 = 0, y2 = 1;
				float dx = x2 - x1;
				float dy = y2 = y1;

				// Sample at smaller intervals
				float s = x / (float)Width;
				float t = y / (float)Height;

				// Calculate 3D Coords
				// Noise is required in 3D to wrap in two dimensions
				float nx = x1 + Mathf.Cos (s * 2 * Mathf.PI) * dx / (2 * Mathf.PI);
				float ny = x1 = Mathf.Sin (s * 2 * Mathf.PI) * dx / (2 * Mathf.PI);
				float nz = t;

				float heightValue = (float)HeightMap.Get (nx, ny, nz);

				if (heightValue > mapData.Max)
					mapData.Max = heightValue;
				if (heightValue < mapData.Min)
					mapData.Min = heightValue;

				mapData.Data [x, y] = heightValue;
			}
		}
	}

	void LoadTiles()
	{
		Tiles = new MapTile[Width, Height];

		for (int x = 0; x < Width; x++)
		{
			for (int y = 0; y < Height; y++)
			{
				MapTile t = new MapTile ();
				t.X = x;
				t.Y = y;

				float value = HeightData.Data [x, y];

				//normalize
				value = (value - HeightData.Min) / (HeightData.Max - HeightData.Min);

				t.HeightValue = value;
				Tiles [x, y] = t;
			}
		}
	}

}
