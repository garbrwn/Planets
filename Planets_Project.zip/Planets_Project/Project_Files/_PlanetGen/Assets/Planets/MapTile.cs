﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MapTile  
{
	// Noise value
	public float HeightValue { get; set; }
	// Coordinates
	public int X, Y;
}
