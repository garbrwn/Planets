﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rotateObject : MonoBehaviour {

	public enum Axis {x,y,z};

	public Axis rotationAxis;
	public float rotationSpeed;

	void FixedUpdate () {

		if (rotationAxis == Axis.x)
			transform.Rotate(new Vector3(rotationSpeed * Time.deltaTime,0,0));

		if(rotationAxis == Axis.y)
			transform.Rotate(new Vector3(0, rotationSpeed * Time.deltaTime, 0));

		if (rotationAxis == Axis.z)
			transform.Rotate (new Vector3 (0, 0, rotationSpeed * Time.deltaTime));

	}
}
