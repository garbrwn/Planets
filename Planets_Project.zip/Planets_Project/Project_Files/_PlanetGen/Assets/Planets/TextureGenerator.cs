﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class TextureGenerator 
{

	private static Color DeepColor = new Color(6/255f, 23/255f, 34/255f, 1);
	private static Color ShallowColor = new Color(11/255f, 41/255f, 59/255f, 1);
	private static Color SandColor = new Color(92 / 255f, 138 / 255f, 36 / 255f, 1);
	private static Color GrassColor = new Color(63 / 255f, 95 / 255f, 25 / 255f, 1);
	private static Color ForestColor = new Color(30 / 255f, 62/ 255f, 19 /255f, 1);
	private static Color RockColor = new Color(0.5f, 0.5f, 0.5f, 1);            
	private static Color SnowColor = new Color(1, 1, 1, 1);


	public static Texture2D GetTexture(int width, int height, MapTile[,] tiles)
	{
		// Create an empty texture
		var texture = new Texture2D (width, height);

		// Create an array of colours to fill texture
		var pixels = new Color [width * height];

		float DeepWater = 0.2f;
		float ShallowWater = 0.4f;  
		float Sand = 0.5f;
		float Grass = 0.7f;
		float Forest = 0.8f;
		float Rock = 0.9f;
		float Snow = 1f;


		for (int x = 0; x < width; x++)
		{
			for (int y = 0; y < height; y++)
			{
				float value = tiles [x, y].HeightValue;

				//Color mapPixel = 
				//pixels[x + y * width] = Color.Lerp(Color.black, Color.red, value);


				// Clamp noise values to colors
				if (value < DeepWater)
					pixels [x + y * width] = DeepColor;
				else if (value < ShallowWater)
					pixels [x + y * width] = ShallowColor;
				else if (value < Sand)
					pixels [x + y * width] = SandColor;
				else if (value < Grass)
					pixels [x + y * width] = GrassColor;
				else if (value < Forest)
					pixels [x + y * width] = ForestColor;
				else if (value < Rock)
					pixels [x + y * width] = RockColor;
				else if (value < Snow)
					pixels [x + y * width] = SnowColor;
			}
			
		}

		texture.SetPixels (pixels);
		texture.wrapMode = TextureWrapMode.Clamp;
		texture.filterMode = FilterMode.Point;
		texture.Apply ();
		Debug.Log ("test");
		return texture;
	}



}
