This project was a small experiment in procedural generation and multi-threading.

Using a third party noise library, I generated arrays of numbers, clamping them between
certain values to represent different areas within the world generated, from seas to mountains.

These clamped values are then used to draw a texture, which is applied to the mesh, giving
the appearance of a planet. The colours are hard coded in this version, but could easily be
exposed to a user interface.

Each generation is based on a seed value, if one is not provided it is generated randomly.

The noise was generated in three dimensions in order to wrap around in two.

Multithreading was employed so that there would no freezing during the generation of data.

